SECRET_KEY = 'chave-secreta'
DEBUG = True

DB_HOST = 'localhost'
DB_NAME = r'C:\Users\Aluno\Desktop\API_RESTT\BANCO\BANCO.FDB'

DB_USER = 'sysdba'
DB_PASSWORD = 'sysdba'